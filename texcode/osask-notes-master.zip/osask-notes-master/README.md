osask-notes
===========

《30 天自制操作系统》（人民邮电出版社）读书笔记



----------

文档发布在Github 上，将随着阅读进度不定期更新。请访问 [https://github.com/mengyingchina/osask-notes](https://github.com/mengyingchina/osask-notes)
获取文档最新的版本。

如果发现文档中有文字错误，请到 [https://github.com/mengyingchina/osask-notes/issues](https://github.com/mengyingchina/osask-notes/issues) 提出。

原书的版权声明一节，有：

> 本书中文简体字版由Mynavi Corporation 授权人民邮电出版社独家出版。未经出版者书面许可，不得以任何方式复制或抄袭本书内容。

由于部分内容摘自书中，不清楚这样摘录部分内容会不会存在版权问题，如果有版权问题，我会及时删除相关内容，请知情者[告知][mail]，谢谢！


[mail]: mailto:mail@wanhu.me "邮箱"

